package br.com.sifatecommerce;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SifatecommerceApplication {

	public static void main(String[] args) {
		SpringApplication.run(SifatecommerceApplication.class, args);
	}

}
